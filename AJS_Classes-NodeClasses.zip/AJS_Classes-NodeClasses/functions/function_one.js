function fun_one(){
    document.write("<h1>AngularJS</h1>");
}