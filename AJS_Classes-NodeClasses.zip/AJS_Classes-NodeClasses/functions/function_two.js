
function fun_two(){
    fun_one();
}