var var_one = "AngularJS";
var var_two = "NodeJS";
var var_three = "Mongo DB";