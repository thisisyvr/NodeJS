app.controller("homeController",homeController);
function homeController($scope){
    $scope.var_one="Welcome to Home Page";
}