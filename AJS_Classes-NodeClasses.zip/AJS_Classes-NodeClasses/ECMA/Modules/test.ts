export interface Test{
    sub_one:string;
    sub_two:string;
    sub_three:string;
}