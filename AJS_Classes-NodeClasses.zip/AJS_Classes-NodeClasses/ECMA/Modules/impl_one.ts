import test = require("./test");
export class impl_one implements test.Test{
    sub_one="AngularJS";
    sub_two="NodeJS";
    sub_three="MongoDB";
}