"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var impl_one = (function () {
    function impl_one() {
        this.sub_one = "AngularJS";
        this.sub_two = "NodeJS";
        this.sub_three = "MongoDB";
    }
    return impl_one;
}());
exports.impl_one = impl_one;
