import one = require("./test");
import two = require("./impl_one");

var obj= new two.impl_one();
document.write(""+obj);