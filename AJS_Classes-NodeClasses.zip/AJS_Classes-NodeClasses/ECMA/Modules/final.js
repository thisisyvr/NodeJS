"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var two = require("./impl_one");
var obj = new two.impl_one();
document.write("" + obj);
