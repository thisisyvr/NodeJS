var data : string = "Data....!";
var my_num:number = 100;
var var_one : boolean = true;