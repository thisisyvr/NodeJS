var data = "Data....!";
var my_num = 100;
var var_one = true;
