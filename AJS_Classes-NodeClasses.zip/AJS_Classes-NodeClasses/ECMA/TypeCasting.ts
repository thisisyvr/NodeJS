var var_one:string = "100";
var var_two:number =<number><any>var_one;


var bool_type:boolean = true;
var number_type:number=0x111;
var str_type:string="Welcome";
var any_type:any=1000;