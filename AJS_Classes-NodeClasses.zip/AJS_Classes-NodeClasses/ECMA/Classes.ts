class  Class_one
{
    var_one:number;
    constructor(arg1:number){
        this.var_one=arg1;
    }
}

var obj = new Class_one(100);
console.log(obj.var_one);  //100